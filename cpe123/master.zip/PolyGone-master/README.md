PolyGone
========

Cal Poly Prestige Worldwide Poly-Gone Tower Defense

Team Members:
Cameron Geehr
Bryan Sugiarto
Colin VanDervoort
Mei-Ru Chen
Kevin McKinnis

Our app is a polygon themed tower defense game. There are 3 different types of towers that can be added onto the maps.
There are 3 different difficulties, and each of those links to a different map of decreasing length. There is a main 
menu screen with Play! and Options on it, options links you to a slider labeled BGM which can change the
volume of the background music. In the game itself, towers can be added for money, and the towers shoot 
enemies once they come into range of the towers. When the bullets collide with the enemies they change shape and the 
number of sides on the shape is lowered (ie. from square to triangle). The enemies are removed from the screen when they
reach the bottom of the screen and the amount of lives the player has is lowered by the amount of remaining lives the
enemy has (ie. enemy is pentagon with 3 lives, player goes from 50->47 lives). Waves of enemies of increasing difficulty 
come once the map has been selected. There are three types of towers: normal, bomb, and fire. Normal just removes one life
when enemies are shot and has the full range of the screen, bomb hits all of the enemies within a certain range, and when 
enemies are shot with the fire tower the enemies are set on fire and lose health over time.
