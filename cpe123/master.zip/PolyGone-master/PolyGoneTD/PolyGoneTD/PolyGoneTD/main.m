//
//  main.m
//  PolyGoneTD
//
//  Created by Cameron Geehr on 10/24/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
