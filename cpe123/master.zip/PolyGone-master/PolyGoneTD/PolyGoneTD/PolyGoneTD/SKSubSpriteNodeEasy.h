//
//  SKSubSpriteNodeEasy.h
//  PolyGoneTD
//
//  Created by bsugiart on 11/12/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKSubSpriteNodeEasy : SKSpriteNode

@end
