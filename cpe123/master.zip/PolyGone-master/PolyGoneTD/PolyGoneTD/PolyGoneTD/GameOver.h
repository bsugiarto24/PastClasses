//
//  GameOver.h
//  PolyGoneTD
//
//  Created by Bryan Sugiarto on 11/7/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameOver : SKScene
-(id)initWithSize:(CGSize)size score: (int) killed;
@end
