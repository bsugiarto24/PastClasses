//
//  MainMenu.h
//  Poly-Gone
//

//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface MainMenu : SKScene

@end
