//
//  ToolbarTower.h
//  PolyGoneTD
//
//  Created by Kevin McKinnis on 10/31/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import "Tower.h"

@interface ToolbarTower : Tower

@end
