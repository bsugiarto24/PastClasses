//
//  SKSubSpriteNodeHelp.h
//  PolyGoneTD
//
//  Created by Bryan Sugiarto on 12/3/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKSubSpriteNodeHelp : SKSpriteNode

@end
