//This class allows the object clicked on to bring the user to the difficulty menu
//
//  SKSubSpriteNode2.h
//  Poly-Gone
//
//  Created by Cameron Geehr on 10/18/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKSubSpriteNode2 : SKSpriteNode

@end
