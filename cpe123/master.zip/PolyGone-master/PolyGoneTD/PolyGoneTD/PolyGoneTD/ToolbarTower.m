//
//  ToolbarTower.m
//  PolyGoneTD
//
//  Created by Kevin McKinnis on 10/31/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import "ToolbarTower.h"

@implementation ToolbarTower

- (instancetype) init
{
    self = [super init:CGPointMake(300, 150) init1:1];
    return self;
}

@end
