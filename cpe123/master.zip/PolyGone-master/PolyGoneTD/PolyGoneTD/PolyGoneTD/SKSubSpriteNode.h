//This class allows the object clicked on to bring the user to the options menu
//
//  SKSubSpriteNode.h
//  Poly-Gone
//
//  Created by Cameron Geehr on 10/17/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKSubSpriteNode : SKSpriteNode

@end
