//
//  TowerOne.h
//  PolyGoneTD
//
//  Created by Kevin McKinnis on 10/31/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import "Tower.h"
#import <SpriteKit/SpriteKit.h>

@interface TowerOne : Tower

- (instancetype) init:(CGPoint) x;
-(instancetype) init;

@end
