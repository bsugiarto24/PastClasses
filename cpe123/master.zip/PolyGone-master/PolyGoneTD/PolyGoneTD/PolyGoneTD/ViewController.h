//
//  ViewController.h
//  Poly-Gone
//

//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController

@property (nonatomic) AVAudioPlayer * backgroundMusicPlayer;

@end
