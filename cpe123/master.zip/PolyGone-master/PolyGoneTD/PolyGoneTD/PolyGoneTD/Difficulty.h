//
//  Difficulty.h
//  Poly-Gone
//
//  Created by Cameron Geehr on 10/18/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface Difficulty : SKScene



@end
