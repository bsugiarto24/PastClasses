//
//  Options.h
//  Poly-Gone
//

//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
@import AVFoundation;

@interface Options : SKScene
@property (nonatomic) AVAudioPlayer * backgroundMusicPlayer;
@end
