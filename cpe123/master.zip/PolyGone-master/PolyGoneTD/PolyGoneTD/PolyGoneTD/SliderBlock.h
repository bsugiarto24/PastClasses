//
//  SliderBlock.h
//  PolyGoneTD
//
//  Created by Cameron Geehr on 10/24/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SliderBlock : SKSpriteNode

-(instancetype) init;

@end
