//This class allows the object clicked on to bring the user to the map screen
//
//  SKSubSpriteNode3.h
//  Poly-Gone
//
//  Created by Cameron Geehr on 10/22/13.
//  Copyright (c) 2013 Cameron Geehr. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKSubSpriteNodeHard : SKSpriteNode

@end
